var searchData=
[
  ['n1nbr_0',['n1nbr',['../class_base.html#a26991ab4a5ff1f0668d6f239813c6c69',1,'Base']]],
  ['n2nbr_1',['n2nbr',['../class_base.html#a37962e6e1e2424dea21f7036289ee84c',1,'Base']]],
  ['nf_2',['nf',['../class_bcc_jump.html#a530520bcb0ea7d262771c92e9ab81f93',1,'BccJump::nf'],['../class_multi_bcc_jump.html#a6659e5335c335bbd0c4660c7f046608a',1,'MultiBccJump::nf'],['../class_multi_size_bcc_jump.html#ab4ee8a43133696e5083d81894b5a40e6',1,'MultiSizeBccJump::nf']]],
  ['nm_3',['nm',['../struct_base_1_1_v_a_c.html#a25ef987b894c9412550021b9db7bb7db',1,'Base::VAC']]],
  ['nn1_4',['nn1',['../class_single_bcc.html#a0a282d360abf966f61794030a4762d01',1,'SingleBcc::NN1'],['../class_single_fcc.html#a295121bfc2d3755b5b6e384265f9fc62',1,'SingleFcc::NN1'],['../class_multi_bcc.html#a4a02d01cace8ec697327098d0d2470b7',1,'MultiBcc::NN1'],['../class_multi_fcc.html#a1063a46174a0f167d99facdbf1a10995',1,'MultiFcc::NN1'],['../class_multi_size_bcc.html#abc31f15ac19799262d6a52eded9e1dc7',1,'MultiSizeBcc::NN1'],['../class_multi_size_fcc.html#afe1ce52c9c82b90dcaa910d3eae1e604',1,'MultiSizeFcc::NN1'],['../class_para_bcc.html#a9988f0802c78d3460516f28033973533',1,'ParaBcc::NN1']]],
  ['nn2_5',['nn2',['../class_single_bcc.html#aa2d9679be39345b7aefb872fb9a8916a',1,'SingleBcc::NN2'],['../class_single_fcc.html#aa06f44d7394e6f0e86a456baaca39c1b',1,'SingleFcc::NN2'],['../class_multi_bcc.html#a1a74e9b36bc5372bcfc634a59ed92767',1,'MultiBcc::NN2'],['../class_multi_fcc.html#a31f8c453185180b46646ef2b0bdc402a',1,'MultiFcc::NN2'],['../class_multi_size_bcc.html#aa94d2c76f3114f437d897e06785361fa',1,'MultiSizeBcc::NN2'],['../class_multi_size_fcc.html#a4e26e05aa4acea4fb0b64d9d342a0ef7',1,'MultiSizeFcc::NN2'],['../class_para_bcc.html#afacb4722b97fba752a5317d6d2057f3c',1,'ParaBcc::NN2']]],
  ['numbericaldensity_6',['NumbericalDensity',['../class_crystal_method.html#aa6cd8e50c00a5889a1c5d8031826376e',1,'CrystalMethod']]],
  ['numeric_7',['l include &lt;numeric&gt;',['../md__x_e7_x_a_c_x_a_c_x_e4_x_b8_x89_x_e6_x96_x_b9_x_e5_x8_c_x85.html#autotoc_md10',1,'']]],
  ['numthreads_8',['numThreads',['../class_simulation_parameters.html#aba20883a226b70e7192db8be411b1b7b',1,'SimulationParameters']]],
  ['nx_9',['nx',['../class_crystal_method.html#add3ff219d0c4b42ccb3cfba0b55c4f19',1,'CrystalMethod::nx'],['../class_simulation_parameters.html#a268eb42a7c4febab6eb52da3d197bde0',1,'SimulationParameters::nx']]],
  ['ny_10',['ny',['../class_crystal_method.html#ac217a2c3f2062f40d4fddaccd9345078',1,'CrystalMethod::ny'],['../class_simulation_parameters.html#a2070c5c74594a5876ad399ab730b8cb3',1,'SimulationParameters::ny']]],
  ['nz_11',['nz',['../class_crystal_method.html#a65a5a4be7e018908bbf7358ab5ad092b',1,'CrystalMethod::nz'],['../class_simulation_parameters.html#ab27704590c3d9ee2782272b7faaaae1e',1,'SimulationParameters::nz']]]
];
