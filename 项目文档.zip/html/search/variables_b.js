var searchData=
[
  ['radius_5fstart_0',['radius_start',['../class_crystal_method.html#aa4b96b8e88deea45af4ba5bb87285bf2',1,'CrystalMethod']]],
  ['read_5ffile_1',['read_file',['../class_simulation_parameters.html#a19830917cd6835794fcbba2e4d0caf86',1,'SimulationParameters']]]
];
