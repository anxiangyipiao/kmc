var searchData=
[
  ['time_5fconf_0',['time_conf',['../class_simulation_parameters.html#adf9a61403c90210f92e92efc511701d0',1,'SimulationParameters']]],
  ['tpair_1',['TPair',['../class_crystal_method.html#a5e3c4cd61d11b716e88f980ee03e0266',1,'CrystalMethod']]]
];
