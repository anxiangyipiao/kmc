var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwxyz~串介使包参安并数第",
  1: "bcfjmpstv",
  2: "ikm介第",
  3: "abcdefgimoprstu~",
  4: "abcdeflmnoprstuvwxyz",
  5: "c",
  6: "_",
  7: "k包参"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "宏定义",
  7: "页"
};

