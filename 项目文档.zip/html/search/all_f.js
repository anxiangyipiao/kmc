var searchData=
[
  ['outposcar_0',['outposcar',['../class_simulation_parameters.html#ab5c193661726584cbd58e203dbe8da43',1,'SimulationParameters']]],
  ['outsize_1',['OutSize',['../class_crystal_method.html#a03bd22982000263297c8474641ee7b52',1,'CrystalMethod']]]
];
