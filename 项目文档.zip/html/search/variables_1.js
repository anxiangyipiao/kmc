var searchData=
[
  ['blist_0',['BList',['../class_base.html#a0e9b992518d9de3f81c04829a2644bd1',1,'Base']]],
  ['bnum_1',['Bnum',['../class_base.html#a216eaa6f2f3ba0d1e9e7c808d9f509fc',1,'Base']]]
];
